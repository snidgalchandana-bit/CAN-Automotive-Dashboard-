/*
 * File:   newmain.c
 * Author: snidg
 *
 * Created on 7 May, 2025, 5:36 PM
 */
#include <xc.h>
#include "adc.h"
#include "can.h"
#include "newmain.h"
//#include "clcd.h"
#include "matrix_keypad.h"

void config() {
    init_adc();
    init_matrix_keypad();
   
//    init_clcd();
//    clcd_print("RPM  INDICATOR", LINE1(0));

}
unsigned char rpm_tx[5];
unsigned char indicator_tx[2];

//unsigned char msg;
//unsigned int len1, len2;
//unsigned char rpm_rx[5];
//unsigned char indicator_rx[2];

void main(void) {
    config();
     init_can();
    //    static unsigned char ssd[MAX_SSD_CNT];
    //    static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    unsigned long int delay = 0, RPM;
   unsigned char ind = '-';
    char key;
    while (1) {
        RPM = read_adc(CHANNEL4)*5.865;
        rpm_tx[0] = (RPM / 1000) + 48;
        rpm_tx[1] = ((RPM / 100) % 10) + 48;
        rpm_tx[2] = ((RPM / 10) % 10) + 48;
        rpm_tx[3] = (RPM % 10) + 48;
        can_transmit(4, msg_id_rpm, rpm_tx);
         __delay_ms(500);
//        can_receive(&len1, &msg, rpm_rx);
//        clcd_putch(rpm_rx[0], LINE2(0));
//        clcd_putch(rpm_rx[1], LINE2(1));
//        clcd_putch(rpm_rx[2], LINE2(2));
//        clcd_putch(rpm_rx[3], LINE2(3));

        key = read_switches(STATE_CHANGE);

        if (key == MK_SW1) {
            ind = 'R';
//            clcd_print("W",LINE2(9));
        } else if (key == MK_SW2) {
            ind = 'L';
        } else if (key == MK_SW3) {
            ind = 'O';
        }
        indicator_tx[0] = ind;
        can_transmit(1, msg_id_ind, indicator_tx);
         __delay_ms(500);
//        if (can_receive(&len1, &msg, indicator_rx)) {
//            clcd_print("hello",LINE2(10));
//            clcd_putch(indicator_rx[0], LINE2(5));
//        } else {
//            clcd_putch('E', LINE2(5)); // Error indicator
//        }
    }
    return;
}
