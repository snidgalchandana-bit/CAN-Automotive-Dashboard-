 /* 
 * File:   main.h
 * Author: snidg
 *
 * Created on 15 May, 2025, 5:41 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define msg_id_gear 0x10
#define msg_id_speed 0x20
#define msg_id_temp 0x30
#define _XTAL_FREQ 2000000
#endif	/* MAIN_H */

