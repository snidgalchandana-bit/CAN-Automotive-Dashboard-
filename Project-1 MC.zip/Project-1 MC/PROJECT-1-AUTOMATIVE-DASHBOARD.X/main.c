/*
 * File:   main.c
 * Author: snidg
 *
 * Created on 5 May, 2025, 4:01 PM
 */


#include <xc.h>
#include "adc.h"
#include "main.h"
#include "can.h"
//#include "clcd.h"
#include "matrix_keypad.h"

unsigned char GEAR[2];
unsigned char SPEED[3];
unsigned char TEMP[3];

//unsigned int len1;
//unsigned char msg_id;
//unsigned int gear_recieve[8];
//
//unsigned int len2;
//unsigned char speed_recieve[8];
//
//unsigned int len3;
//unsigned char temp_recieve[8];

void config() {
    init_can();
    //init_clcd();
    init_matrix_keypad();
    init_adc();
    
    //clcd_print("GEAR SPEED TEMP", LINE1(0));
}

void main(void) {
    config();
    unsigned int speed, temp;
    unsigned char key;
    int gear = 0, prev;
    while (1) {

        key = read_switches(STATE_CHANGE);

        if (key == MK_SW1) {
            if (gear < 5) {
                gear++;
            } else if (gear == 7) {
                gear = 0;
            }
        } else if (key == MK_SW2) {
            if (gear <= 5) {
                if (gear > 0) {
                    gear--;
                } else {
                    gear = 0;
                }
            }
        } else if (key == MK_SW3) {
            gear = 7;
        }
        GEAR[0] = gear + 48;
        can_transmit(1, msg_id_gear, GEAR);
         __delay_ms(500);
//        can_receive(&len1, &msg_id, gear_recieve);
//        clcd_putch(gear_recieve[0], LINE2(2));

        speed = read_adc(CHANNEL4) / 10.33;
        SPEED[0] = (speed / 10) + 48;
        SPEED[1] = (speed % 10) + 48;
        can_transmit(2, msg_id_speed, SPEED);
         __delay_ms(500);
//        can_receive(&len2, &msg_id, speed_recieve);
//        clcd_putch(speed_recieve[0], LINE2(5));
//        clcd_putch(speed_recieve[1], LINE2(6));

        int temp = ((read_adc(CHANNEL6)*(float)5)/(float)1023)*100;
        
        
        TEMP[0] = (temp / 10) + 48;
        TEMP[1] = (temp % 10) + 48;
        TEMP[2] = 0xDF;
        TEMP[3] = 'C';      
        can_transmit(4, msg_id_temp, TEMP);
        __delay_ms(500);
//        can_receive(&len2, &msg_id, temp_recieve);
//        clcd_putch(temp_recieve[0], LINE2(11));
//        clcd_putch(temp_recieve[1], LINE2(12));
//        clcd_putch(temp_recieve[2], LINE2(13));
//        clcd_putch(temp_recieve[3], LINE2(14));

    }
    return;
}
