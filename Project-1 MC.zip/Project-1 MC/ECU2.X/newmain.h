/* 
 * File:   newmain.h
 * Author: snidg
 *
 * Created on 21 May, 2025, 12:33 PM
 */

#ifndef NEWMAIN_H
#define	NEWMAIN_H

#define msg_id_rpm 0x40
#define msg_id_ind 0x50
#define _XTAL_FREQ 2000000

#endif	/* NEWMAIN_H */

