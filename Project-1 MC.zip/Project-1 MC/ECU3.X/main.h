/* 
 * File:   main.h
 * Author: snidg
 *
 * Created on 22 May, 2025, 1:48 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define msg_id_gear 0x10
#define msg_id_speed 0x20
#define msg_id_temp 0x30
#define msg_id_rpm 0x40
#define msg_id_ind 0x50



#endif	/* MAIN_H */

